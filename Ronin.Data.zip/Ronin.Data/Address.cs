﻿using Ronin.Obj.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Ronin.Data
{
    [Table("Address")]
    public class Address : IAddress
    {
        [Key]
        public int AddressID { get; set; }

        [Column("Data")]
        internal string JSONAddress { get; set; }

        [NotMapped]
        public string FormattedAddress { get; set; }

        [NotMapped]
        public string Route { get; set; }
        [NotMapped]
        public string PostalCode { get; set; }

        [NotMapped]
        public string Locality { get; set; }

    }
}
