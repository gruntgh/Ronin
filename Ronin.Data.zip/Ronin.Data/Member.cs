namespace Ronin.Data
{
    using Ronin.Obj.Interface;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using Ronin.Obj;

    [Table("Member")]
    public partial class MemberEF : IMember
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        public string LastName { get; set; }

        [Column(TypeName = "date")]
        public DateTime Birth { get; set; }

        public Gender Gender { get; set; }

        public string FiscalCode { get; set; }
        public string BirthLocality { get; set; }
        public string Job { get; set; }

        [ForeignKey("Address")]
        public int AddressID { get; set; }
                
        public virtual Address Address { get; set; }

        //[Column("AddressID", TypeName = "int")]
        //[NotMapped]
        //public string Address { get; set; }
        public string Mail { get; set; }
        public string Phone { get; set; }
        IAddress IMember.Address { get { return Address; } set { } }

        public static explicit operator Member(MemberEF m)
        {
            return new Member((IMember)m);
        }
    }
}
